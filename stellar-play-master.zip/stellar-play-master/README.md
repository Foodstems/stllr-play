# stellar-play
Tests

### Installation
```npm install```

### Run
```node ./test.js```
