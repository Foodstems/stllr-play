var StellarSdk = require('stellar-sdk');

var md5 = 'd41d8cd98f00b204e9800998ecf8427e';
var value = md5+md5;

const buf = Buffer.from(value, 'hex');

console.log('Stellar memo hash is', buf.toString('base64'));

var hash = new StellarSdk.Memo(StellarSdk.MemoHash, value);
//console.log(/^[0-9A-Fa-f]{64}$/g.test(value));
//return false;

	var server = new StellarSdk.Server('https://horizon-testnet.stellar.org');
	StellarSdk.Network.useTestNetwork();
	var sourceSecretKey = 'SBABKJ36RL5BW2A6RCVPPTVGGBMHTRLI7CZH25RC3UCH3DIZHWMBYWLK';

	var sourceKeypair = StellarSdk.Keypair.fromSecret(sourceSecretKey);
	var stellar_public_key = sourceKeypair.publicKey();
	var receiverPublicKey = 'GA3TS46MPMIBYFU6IZCXXI54265AKLNM36SG6DVHI4KLK5H6TDTWFAQY';
	server.loadAccount(stellar_public_key)
  .then(function(account) {
    var transaction = new StellarSdk.TransactionBuilder(account)
      // Add a payment operation to the transaction
      .addOperation(StellarSdk.Operation.payment({
        destination: receiverPublicKey,
        // The term native asset refers to lumens
        asset: StellarSdk.Asset.native(),
        // Specify 350.1234567 lumens. Lumens are divisible to seven digits past
        // the decimal. They are represented in JS Stellar SDK in string format
        // to avoid errors from the use of the JavaScript Number data structure.
        amount: '350.1234567',
      }))
      // Uncomment to add a memo (https://www.stellar.org/developers/learn/concepts/transactions.html)
      .addMemo(hash)
      .build();

    // Sign this transaction with the secret key
    // NOTE: signing is transaction is network specific. Test network transactions
    // won't work in the public network. To switch networks, use the Network object
    // as explained above (look for StellarSdk.Network).
    transaction.sign(sourceKeypair);

    // Let's see the XDR (encoded in base64) of the transaction we just built
    //console.log(transaction.toEnvelope().toXDR('base64'));

    // Submit the transaction to the Horizon server. The Horizon server will then
    // submit the transaction into the network for us.
    server.submitTransaction(transaction)
      .then(function(transactionResult) {
        //console.log(JSON.stringify(transactionResult, null, 2));
        //console.log('\nSuccess! View the transaction at: ');
        console.log(transactionResult._links.transaction.href);
      })
      .catch(function(err) {
        console.log('An error has occured:');
        console.log(err);
      });
  })
  .catch(function(e) {
    console.error(e);
  });

//var hash = new StellarSdk.Memo(StellarSdk.MemoHash, value);
//console.log(hash.value);